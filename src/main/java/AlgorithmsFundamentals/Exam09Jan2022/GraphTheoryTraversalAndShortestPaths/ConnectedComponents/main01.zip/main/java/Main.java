import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Main {
//    public static class Edge{
//        public int source;
//        public int destination;
//
//        public Edge(int source, int destination) {
//            this.source = source;
//            this.destination = destination;
//        }
//    }

    public static void main(String[] args) {

//        new Edge(1,3);

        List<List<Integer>> graph = new ArrayList<>();

        Scanner scanner = new Scanner(System.in);
        int numberOfLinesN = Integer.parseInt(scanner.nextLine());

        while (numberOfLinesN-- > 0) {
            String line = scanner.nextLine();

            if (line.trim().equals("")) {
                graph.add(new ArrayList<>());
            } else {
                List<Integer> nextNodes = Arrays.stream(line.split("\\s+"))
                        .map(Integer::parseInt)
                        .collect(Collectors.toList());
                graph.add(nextNodes);
            }
        }
        List<Deque<Integer>> connectedComponents = getConnectedComponents(graph);

    }

    public static List<Deque<Integer>> getConnectedComponents(List<List<Integer>> graph) {
        boolean[] visited = new boolean[graph.size()];
        List<Deque<Integer>> components = new ArrayList<>();

        for (int i = 0; i < graph.size(); i++) {
            if (!visited[i]) {
                System.out.printf("Connected component:");
                 dfs(i, graph, components, visited);

                System.out.println();
            }
        }

        return components;
    }

    private static void dfs(int node, List<List<Integer>> graph, List<Deque<Integer>> components, boolean[] visited) {
        if (!visited[node]) {
            visited[node] = true;

            for (int child : graph.get(node)) {
                dfs(child, graph, components, visited);
            }
            System.out.print( " " + node);
        }
    }

    public static Collection<String> topSort(Map<String, List<String>> graph) {
        throw new AssertionError("Not Implemented");
    }
}
